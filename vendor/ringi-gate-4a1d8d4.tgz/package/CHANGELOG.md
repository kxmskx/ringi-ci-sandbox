# Changelog

This file lists notable changes of Ringi Gate, newest first. Each version
is tagged `v<version>` and published to npm as `ringi-gate`. Version 0.1.0
is published by hand, without provenance; later versions are published by
`.github/workflows/release.yml`.

## Unreleased

### Added

- The CI adapter for GitHub Actions, part 2: review by a model in CI,
  opt-in (see [docs/ci.md](docs/ci.md), the threat model first). Optional
  `ci.review: { profiles: { docs, full }, maxAttempts, timeoutMinutes,
  credentials }` in the profile: review profiles of `reviewer.profiles` for
  both lanes (the `docs` lane gets a cheaper review, never none), the
  budget per workflow run (attempts of the job in the run and the time of
  the review; across runs the approval of the environment; no cost
  limit, since no provider reports a cost) and the names of the
  credential variables (`*_KEY` or `*_TOKEN`). Any other key is
  `INVALID_CONFIGURATION`, reserved. A profile without `ci.review` behaves
  as before.
- `ringi ci review --base <sha> --head <sha> --event <file> --attempt <n>
  --out <dir> [--summary <file>]`: in a checkout of the base with the
  base's profile, refuses an attempt over the budget, a merge commit whose
  parents are not the base and the head of the event, a missing credential,
  a credential shorter than 8 characters and a change of the profile, of
  agent instructions or settings (`AGENTS.md`, `CLAUDE.md`,
  `CLAUDE.local.md`, `.mcp.json`, `.claude/`), of `.corepack.env`, of a
  dependency input (the core's names, `package.json` among them, at any
  depth), of a
  `.patch` file or of `node_modules`, and a new symbolic link;
  puts the merge commit's tree in the working tree, generates the task from
  the pull request (title and description quoted as data, cut to 256 and
  4000 characters) and runs the review-only mode with only the `git`
  checks as gates and the credentials in the reviewer's environment alone.
  Prints `verdict=`, `lane=` and `run-id=`; writes `ci-review.json` (with
  the measurement of the commit), the report and the ledger to `--out` and a
  summary without secrets to `--summary`. Existing STOP codes only.
- `ringi ci classify --checks` prints `checks=<JSON array>`;
  `ringi ci aggregate --review-job <job>` requires the review job with
  `verdict=APPROVE` of the same lane, and `--enforce-checks` compares the
  checks the lane jobs ran with the classification's. Without these options
  the output and the check are as before.
- `examples/github-actions/ringi-ci-review.yml`: the example workflow with
  the review job (`environment`, the base checked out as trusted code, the
  merge commit as data, the secret only in the env of the review step,
  `ringi verify` after the review), checked by its own text test.
- `runAgentReviewLoop` options `gitGatesOnly` and `reviewerCredentials`,
  set only by `ringi ci review`.
- The CI adapter for GitHub Actions, part 1 (see
  [docs/ci.md](docs/ci.md)); no model and no secret in CI. Optional
  `ci: { docsPaths, lanes }` in the profile: `docsPaths` in the dialect and
  with the validator of review lane `paths` (an exact file must end in
  `.md`), `lanes: { docs, full }` with check names of the profile, the
  `docs` lane a subset of the `full` lane; any other key of `ci` or
  `ci.lanes` is `INVALID_CONFIGURATION`, reserved. A profile without `ci`
  behaves as before.
- `ringi ci classify --base <sha> --head <sha> [--json]`: the lane of the
  real diff between two commits (`git diff-tree -r -z --raw` with renames
  and copies, without the user's Git configuration or replace objects).
  `docs` only when every file, both ends of a rename or copy included, is a
  `.md` file under `docsPaths` in mode `100644`, not `AGENTS.md`,
  `CLAUDE.md`, `SECURITY.md` or `SKILL.md` in any letter case, not excluded
  by the docs candidate rule (its base exclusions and the profile's
  `docsCandidatePolicy` exclusions, with the core's own code), not a file
  of the profile, without a segment starting with a dot; anything else, an
  empty diff included, is `full` with its reasons. `--head` must be `HEAD`
  of the checkout. A diff that cannot be classified stops with an existing
  code (`DIFF_FAILED`, `DIFF_TOO_LARGE`, `INVALID_CONFIGURATION`,
  `PROFILE_UNCOMMITTED`, `TIMEOUT`, `INTERRUPTED`, `UNEXPECTED_ERROR`) and
  is never a lane; `GIT_DIR` or `GIT_WORK_TREE` in the environment is exit
  code `2` without a code.
- `ringi ci aggregate --lane <lane> --needs <file> --classify-job <job>
  --docs-jobs <jobs> --full-jobs <jobs>`: the required check from
  `toJSON(needs)`, green only when the classification and every job of the
  lane succeeded and every other job was skipped.
- `examples/github-actions/ringi-ci.yml`: the example workflow
  (`pull_request` with the draft, ready and `edited` events, `push` to the
  default branch, `ringi-gate` installed with pnpm without install scripts, `contents: read`, actions pinned to a commit SHA, concurrency per
  pull request, a draft never green, an aggregator that always runs under a
  fixed name), checked by `examples/validate-examples.test.mjs`, and the
  CI budget policy in `docs/ci.md`.

## 1.0.0 — 2026-10-30

The first stable version: the contract in
[docs/contract.md](docs/contract.md) is frozen, and a breaking change of
it needs a major version. The provider-specific names stay as deprecated
aliases until 2.0; the built-in providers stay `experimental`.

### Added

- Risk routing, part 1: optional `routing: { rules }` in the profile,
  deterministic named rules. A rule named after a task class is that class's
  rule; any other name is an escalation rule, used only as the target of an
  escalation, without `escalate` or `implementerEffort` of its own, and some
  rule must escalate to it (so a misspelt class name is
  `INVALID_CONFIGURATION`). Any key of `routing` other than `rules` is
  `INVALID_CONFIGURATION`, reserved for later options. A rule may set
  `implementerEffort` (from `implementer.allowedEfforts`), `reviewProfile`
  (from `reviewer.profiles`), `reviewLanes` (ids of the profile's lanes or
  `'all'`) and `addChecks` (checks added to the class's set, never replacing
  one), and must have a `reason` (up to 500 characters). `escalate` (1 to 16
  entries `{ paths, to }`, the path dialect and validator of lane `paths`)
  switches the gates and the review to the strictest matching rule when the
  candidate touches a path; every entry is checked against the whole
  candidate in the preflight and after each writer round, routing only moves
  up and a target's own entries are never followed; the writer's effort
  stays, and a lane with its own `profile` keeps it. Profile validation
  refuses, with `INVALID_CONFIGURATION`, any value outside the profile, any
  key that would change a class, switch the review off or replace checks, an
  escalation that lowers the review effort (by the order of the reviewer
  provider's efforts), drops a lane or drops an added check, and targets of
  one rule that are not pairwise comparable; review profiles that cannot be
  compared (other models or attempts) cannot be escalated between. Authors
  of `providerModules`: the module's `efforts` must now be listed from the
  lowest to the highest, since routing compares review efforts by that
  order; the contract does not check the order, and the built-in modules
  already list theirs that way. `--implementer-effort` and
  `--review-profile` win over the rule, also below it, and the report lists
  them in `routing.overriddenBy`. The report (also with `--review-only`,
  `--dry-run` and `--resume`) adds `routing` (`class`, `rule`,
  `escalatedBy`, `applied`, `overriddenBy`, `reason`, and
  `checkpointDifferences` in a resumed run, which computes the routing again
  and does not stop on a difference); the ledger adds a `routing` event and
  a checkpoint stores the routing. The `analysis` mode ignores routing. A
  `ringi verify` older than routing rejects a ledger with a `routing` event.
  `schemaVersion` stays 1 and a profile without `routing` runs exactly as
  before.
- `docs/contract.md`: what version 1.0 promises and what changes only in a
  major version: the CLI commands, options and exit codes, the top-level
  profile keys, the top-level report fields (`schemaVersion` 1), every STOP
  code with its meaning and whether it is resumable, the ledger event
  types, the provider module interface, what is outside the contract, and
  what 1.0 promises for an `experimental` provider. Contract tests pin each
  list against the code and the document.

### Changed

- `codex` implementer in a linked worktree or a submodule (`.git` is a
  file): the sandbox check before every round also opens that `.git` file
  for writing, without changing it, and requires the sandbox to refuse it
  with a permission error and the file to be unchanged afterwards;
  otherwise `IMPLEMENTER_PREFLIGHT_FAILED` (`git-pointer-write` or
  `no-evidence`) before the implementer. That shows the sandbox refuses to
  write the file in place. After every writer round of any implementer,
  before any Git command of the core, the core also compares the file's
  bytes and type with those before the round: a file renamed or removed and created again
  (other bytes, or a symbolic link) stops the run with
  `UNEXPECTED_GIT_MUTATION` (stage `post-implementer`). Before, the
  implementer could have pointed the file's `gitdir:` line to another
  directory if the sandbox left it writable. The `.git` file must now be a
  single `gitdir: <path>` line, as Git reads it; a second line is
  `IMPLEMENTER_PREFLIGHT_FAILED` (`git-directory`), like a `.git` that is a
  symbolic link. A repository whose `.git` is a directory runs the same
  check as before.
- `--resume` refuses a signed checkpoint whose writer report answers a
  finding with `NEEDS_HUMAN` (`INTEGRITY_CHECK_FAILED`, like any other
  malformed checkpoint): a run stops on that answer before it saves the
  checkpoint, so only a forged checkpoint can carry it.
- Review-only runs: the terminal dashboard shows the implementer as not run
  instead of its unused model. The report is unchanged.
- `ringi verify --help` says when a ledger is `unverified`, and
  `docs/ledger.md` that ledgers of runs from before the key was created stay
  `unverified` once it exists.
- Documentation: a run report has no `agents` field; it is a field of the
  dry-run plan, as the code always did.

## 0.2.5 — 2026-10-29

### Added

- Context packages of review lanes: optional `paths` in a lane (1 to 32
  directory prefixes ending with `/` or exact file paths, compared by
  normalized POSIX segments and case-sensitively; globs, absolute paths,
  `..`, empty entries and duplicates are `INVALID_CONFIGURATION`). A lane
  with `paths` starts from its own part of the full diff, a read-only file of
  the snapshot (`.review-context/lane-<id>.diff`) covered by the snapshot
  hash; its prompt names that file, its SHA-256 and every changed file, but
  carries no diff content. A lane without `paths` gets the
  same prompt as before, byte for byte. Every lane still runs on the same
  complete read-only snapshot: a package saves context and is not
  isolation. Before any reviewer starts, every changed file (both sides of
  a rename, a deleted file too) must belong to a lane, otherwise the run
  stops with `INVALID_CONFIGURATION` naming the uncovered files, also in a
  review-only run and after a resume. `reviewer.lanes[]` and the ledger's
  `review-lane` event add `contextBytes` and `diffFiles`, and the terminal
  line of a lane's attempt shows them. `schemaVersion` stays 1.
- Review lanes: optional `reviewLanes` in the profile (1 to 4 lanes
  `{ id, focus, profile? }`, validated fail-closed with
  `INVALID_CONFIGURATION`). Each review round runs one reviewer process per
  lane, in parallel on the same read-only snapshot, each with the
  guarantees of a single reviewer; the lane's focus (a validated phrase) is
  appended to the fixed reviewer prompt. The snapshot and the working tree
  are checked before the stage, around every attempt of every lane and
  after the stage. Findings are merged by `findingId` (highest severity,
  `lanes` lists the lanes that reported it), and the zero findings policy
  applies to the merged list. A lane without a valid result stops the run
  with its own stop code and the report's `lane` field. The report adds
  `reviewer.lanes`, `rounds[].reviewLanes` and `findings[].lanes`, the
  ledger a `review-lane` event per lane; the process runner lets only the
  lanes' processes overlap. A review round with lanes has `reviewLanes`
  and `reviewer.executionField: 'reviewLanes'` instead of the
  `reviewExecution` key. The focus validation guards against mistakes, not
  against prompt injection. A `ringi verify` older than review lanes rejects
  a ledger with a `review-lane` event. `schemaVersion` stays 1 and a profile
  without `reviewLanes` runs exactly as before.
- `ringi run <task> --review-only` (also in
  `scripts/agent-review-loop.mjs`): the uncommitted changes relative to
  `HEAD` go through the gates, the read-only snapshot and a single
  independent review without starting the writer. The writer's CLI is
  neither required nor probed. The fingerprints are taken from the working
  tree at the start, and any change of it during the run stops with the
  existing integrity codes. Zero findings end with `APPROVE`; any finding
  stops with `HUMAN_DECISION_REQUIRED` and the full finding state, without
  a correction round. A working tree without a change other than the task
  file stops with `INVALID_TASK`, a class that skips the review with
  `INVALID_TASK_CLASS`, analysis mode with `INVALID_TASK_MODE`;
  `--task-mode analysis` and the writer options with `--review-only` are
  argument errors. The report, the dry-run plan and the `metadata` event
  add `runMode: 'review-only'`, and `implementer.status: 'NOT_RUN'`;
  `schemaVersion` stays 1 and a run without the option is unchanged.
- `ringi run <task> --checkpoint` and `--resume <runId>` (also in
  `scripts/agent-review-loop.mjs`), opt-in. With `--checkpoint` the runner
  saves `.agent-review-loop/runs/<runId>/checkpoint.json` after the writer's
  round, the gates and the review, signed with an HMAC (SHA-256) key in
  `$XDG_STATE_HOME/ringi` or `~/.local/state/ringi` (directory `0700`, file
  `0600`, created once). `--resume` runs the full preflight and continues
  with the checkpoint's round and findings, only when the signature is
  valid and the task, profile, runner, branch, `HEAD`, round limit and
  working tree match; the round limit counts every run. A resume skips only
  the writer of the interrupted round: the gates and the review always run
  again. Refusals use existing codes: `INTEGRITY_CHECK_FAILED` (key or
  signature), `HUMAN_DECISION_REQUIRED` (another state, a stop that is not
  resumable), `INVALID_CONFIGURATION` (no checkpoint, options). Only the
  stops in `RESUMABLE_STOP_CODES` are resumable; a stop that cannot be
  recorded fails closed. The signature detects a checkpoint changed without
  the key; code running as the user can read the key, so a forged
  checkpoint can change the round or findings history but cannot approve a
  run. Reports add `checkpoint` and `resumedFrom`; `schemaVersion` stays 1,
  and a run without the options has neither field and writes nothing in the
  state directory.
- Run ledger: every run with a run directory appends its evidence to
  `.agent-review-loop/runs/<runId>/ledger.jsonl` (`ledgerVersion` 1, see
  `docs/ledger.md`), one line per phase event with the SHA-256 of the
  previous line and, when the checkpoint key exists, an HMAC of the line;
  each line is synced to disk. Only evidence the report already contains, or
  hashes of it, redacted like the report. A run without checkpoints only
  reads an existing key and never creates it. An event that cannot be
  written stops the run with `INTEGRITY_CHECK_FAILED`. Reports add
  `ledger: { path, events, headHash }`; `schemaVersion` stays 1. A resume
  verifies the ledger of the run it continues (otherwise
  `INTEGRITY_CHECK_FAILED`) and continues its chain. The ledger documents a
  run; the runner never reads it as trusted state.
- `ringi verify <runId> [--json]`: verifies a run's ledger (chain, `seq`,
  every `mac` with the key, the report's `ledger` field and fingerprints,
  the ledger a resumed run continues) and prints `ok` or the first mismatch;
  exit code `0`, `1`, or `2` for invalid arguments. Without the key it
  verifies only the chain and warns that this does not prove authenticity.
  With the key present, a ledger without `mac` is reported as `unverified`
  (exit code `1`): it was written without the key or its `mac` fields were
  removed.

### Security

- `.review-context` is reserved for the review context the runner writes
  into the reviewer's snapshot (full diff, trusted gate report, task and
  instructions, correction context, lane diffs). In earlier versions a
  `.review-context` entry in the working tree (a directory, files or
  symbolic links, written by the writer or present in the repository) could
  add files to that context or redirect the runner's writes, so the
  reviewer could see a context the runner did not write, and the snapshot
  checks did not detect it. Now any path with a `.review-context` segment
  (compared without case, outside the excluded directories such as
  `node_modules`) stops the run with `PATH_ESCAPE` before any snapshot or
  reviewer, in implementation, analysis and review-only runs and after a
  resume. The runner creates the context directory and each context file
  only as new entries and never through a symbolic link (the context
  directory and its files; repository paths follow the next entry). A
  repository without `.review-context` runs as before.
- Symbolic links in the repository could reach outside it. Earlier versions
  checked a link's target only by its text and read repository paths
  through linked parent directories, so a link (for example a chain such as
  `p -> .` and `a -> p/..`) or a tracked directory replaced by a link could
  bring a file from outside the repository into the reviewer's snapshot, and
  copying the snapshot could write outside it. Now a manifest entry whose
  parent directory is a symbolic link, or a link whose resolved target is
  outside the repository, stops the run with `SYMLINK_ESCAPE`. The target
  is resolved through every link on its way, so a dangling link or a loop
  in such a chain stops the run too. The snapshot creates directories one
  segment at a time, copies files with `COPYFILE_EXCL` and creates links
  after every file. `AGENTS.md` and `CLAUDE.md` pass the same check before
  they are read. Links that stay inside the repository work as before,
  including a plain dangling link such as `a -> missing`, with these
  changes: a tracked file whose parent directory is now a symbolic link
  stops the run even when the link points inside the repository, and so do
  a loop of links (`a -> b`, `b -> a`), a link whose chain passes through a
  dangling link (`a -> d/x`, `d -> missing`) and a link whose target climbs
  with `..` after a missing segment.

## 0.2.4 — 2026-10-28

### Added

- `codex` implementer: before every round the core runs a check command
  through `codex sandbox` in the round's mode, without a model and with an
  empty `CODEX_HOME`. A write to the core's temporary directory or to the
  repository's Git directory (the one `.git` names in a linked worktree or
  a submodule) or a connection to a local listener that is not refused, a
  sandbox that does not start, a check that times out or cannot be run,
  or missing evidence stops the run with `IMPLEMENTER_PREFLIGHT_FAILED`
  before the implementer process. The check is a lower bound, not proof
  for `codex exec`: it runs another command path with stricter writable
  roots and no user configuration. Provider modules may declare the
  optional `sandboxCheckArgs`; its argv goes through `forbiddenArgument`
  with `call: 'sandboxCheck'`, the only call where `codex` may set
  `sandbox_mode` (`read-only` or `workspace-write`) and the stricter
  `exclude_tmpdir_env_var` and `exclude_slash_tmp`.
- Sandbox check probe: `scripts/probes/codex-sandbox-check.mjs` runs the
  core's sandbox check with the real Codex CLI in both task modes in a
  synthetic repository and prints the raw `codex sandbox` result; the
  `.github/workflows/codex-sandbox.yml` workflow runs it on Linux (x64 and
  arm64) and macOS with an exact `@openai/codex` version, without secrets
  and without `sudo`. `--expect <pass|stop>` sets the expected result; the
  workflow expects `stop` on the Ubuntu runners (both modes stopped
  because the sandbox did not start) and `pass` on macOS, so a change of
  either result fails the job. The probe is not part of `npm test` and not
  in the npm package.
- `codex` argument grid: `--sandbox-state-json`,
  `--sandbox-state-readable-root`, `--allow-unix-socket`, `-P`,
  `--permission-profile`, `--include-managed-config`, `--enable` and
  `--disable` are forbidden in every `codex` argv, `exec` included, so a
  provider module that passes `codex exec --enable <feature>` is now
  refused.
- `UNPROBED_VERSION` warning: provider roles may declare the optional
  `probedVersions` (`major.minor.patch` texts), checked by the contract and
  the conformance suite. When the CLI version read from the version
  command (`codex-cli 0.160.0`, `2.1.285 (Claude Code)`) is not in the list
  or cannot be read, the run report adds `UNPROBED_VERSION` to the role's
  `warnings` (`implementer.warnings` and `agents.*.warnings` are new;
  the code is added to the existing `reviewer.warnings`) and `ringi doctor` shows `warn` in
  `implementer-cli` or `reviewer-cli` with the probed versions. Status,
  stop codes and exit codes do not change; `schemaVersion` stays 1. Built-in
  values: `codex` implementer `0.160.0`, `claude` implementer `2.1.285`,
  `claude` reviewer `2.1.285` and `2.1.311`.

### Changed

- `codex` implementer on Linux: on the GitHub-hosted Ubuntu 24.04 runners
  (x64 and arm64, default AppArmor restriction of unprivileged user
  namespaces) the sandbox of Codex CLI 0.164.0 does not start, with the
  bundled or the distribution's `bwrap` (`bwrap: loopback: Failed
  RTM_NEWADDR: Operation not permitted`), so the sandbox check stops every
  round with `IMPLEMENTER_PREFLIGHT_FAILED` before the implementer. No
  declaration is checked on Linux; a Linux host where the sandbox starts
  was not probed. The probe documentation, the stability table and the
  module's limitations say so.
- `codex` implementer: the sandbox check passed on Codex CLI 0.164.0 on
  macOS only. On another host or CLI version
  where `codex sandbox` takes another form or reports other error codes,
  every round stops with `IMPLEMENTER_PREFLIGHT_FAILED` before the
  implementer (fail-closed), although the preflight accepts any CLI
  version. A linked worktree or a submodule was not probed: there the
  round starts only if the sandbox refuses the write to its Git directory.
  The check does not try to write the `.git` file in the working tree
  itself, so if the sandbox leaves that file writable, the implementer
  could point its `gitdir:` line elsewhere; this layout was not checked
  before either. A `.git` that is a symbolic link now stops a `codex`
  run with `IMPLEMENTER_PREFLIGHT_FAILED`.

## 0.2.3 — 2026-10-28

### Changed

- `codex` implementer and `claude` implementer and reviewer: the
  preflight accepts any CLI version, including one with a pre-release or
  build suffix and one that cannot be parsed; it no longer stops the run
  for a Codex CLI version outside 0.160.0 up to, but not including,
  0.161.0, or a Claude Code version outside 2.1.285 up to, but not
  including, 2.2.0. A platform other than macOS or Linux still stops the
  run with `IMPLEMENTER_PREFLIGHT_FAILED` or `REVIEWER_PREFLIGHT_FAILED`,
  and the version still goes to the environment report. The declarations
  were probed on Codex CLI 0.160.0 and Claude Code 2.1.285 and 2.1.311
  only, so another version may change flags or sandbox behaviour
  unchecked; in print mode Claude Code ignores sandbox settings it does
  not accept without an error, which is now a known limitation of the
  `claude` implementer instead of a refusal. The roles stay
  `experimental`; in the stability table of `docs/providers.md`,
  criterion 5 is not met for any built-in role, by choice.

- `claude` reviewer (the default reviewer): because of `--restricted`,
  the reviewer no longer applies the user's Claude Code settings files.
  An `apiKeyHelper`, an `env` block (for example `ANTHROPIC_BASE_URL`, a
  proxy, Bedrock or Vertex settings) and `permissions.deny` rules there
  stop applying to the reviewer, as they already did for the `claude`
  implementer. The stored login keeps working; admin-managed (policy)
  settings still apply.

### Fixed

- `claude` reviewer: the argv adds `--restricted` and
  `--strict-mcp-config`, so the CLI no longer reads the settings files
  (`.claude/settings.json`, `.claude/settings.local.json`) or the MCP
  servers of the reviewed copy, which the implementer can write. Probes of
  Claude Code 2.1.311 showed that the earlier argv still read those files
  (their `permissions` were dropped only because the copy was not a
  trusted workspace), that an `env` block of those files reaches the
  processes the CLI starts and a `.mcp.json` server starts when the files
  are read and `--safe-mode` is left out, and that with the new flags the
  files are not read and no canary appeared.
  `--restricted` also ignores the user's settings files (as for the
  `claude` implementer) and confines the file tools to the working
  directory. Admin-managed (policy) settings still apply. The reviewer now
  declares `noUserConfiguration` as `enforced`; the role stays
  `experimental`. See `docs/providers/probes/claude-reviewer.md`.

## 0.2.1 — 2026-10-27

### Added

- Described probes of the real CLIs on macOS for every guarantee the
  built-in roles declare `enforced`: `docs/providers/probes/` (Codex CLI
  0.160.0, Claude Code 2.1.285). The stability table in
  `docs/providers.md` follows their results. Every built-in role stays
  `experimental`.

### Fixed

- `codex` implementer: commands run in a non-login shell (`-c
  allow_login_shell=false` in the argv). Probes of 0.160.0 showed that in
  a login shell the profiles put the system and Homebrew directories
  before the guard directory on `PATH` (`pathGuards`) and add the
  variables they export; with the new argument an executable guard is
  reached in implementation, analysis and resumed rounds. The shell still
  reads `.zshenv` files; see the next entry for the user's `.zshenv`.
  The argument rules refuse `-c allow_login_shell` other than `false`
  for `codex`.
- Implementer environment (`codex` and `claude`): `ZDOTDIR` points to an
  empty read-only directory (mode `0500`) in the run's temporary
  directory, removed with it, so zsh no longer reads the user's
  `.zshenv`. Probes of Codex CLI 0.160.0 showed the guard reached with it
  where a user's `.zshenv` that changes `PATH` had put the real `git`
  first; in probes of Claude Code 2.1.285 such a `.zshenv` exported
  variables to commands but left the guard directory first on `PATH`.
  `/etc/zshenv` is still read and stays a limitation.
- Documentation of the `claude` implementer: probes of 2.1.285 ran
  commands joined with `;` (`echo a; echo b` and a joined command of
  `touch` writes) inside the sandbox without a denial; the documentation
  said such commands are denied. Other joined commands were not probed.

## 0.2.0 — 2026-10-25

### Breaking

- The `stage` field of the report and of STOP errors names the role, not a
  provider:

  | Old value    | New value          |
  | ------------ | ------------------ |
  | `codex`      | `implementer`      |
  | `post-codex` | `post-implementer` |
  | `claude`     | `reviewer`         |

  Other stage values are unchanged.
- Log, dashboard and message labels name the role (`IMPLEMENTER round`,
  `REVIEWER round`, `REVIEWER · review result`, `implementer model`). The
  `pl` catalog and the `pl` prompts name the role as well (`wykonawca`,
  `reviewer`), so their text is no longer byte-identical to the runner
  before the message catalog.
- Every built-in role is declared `experimental`, including the `codex`
  implementer and the `claude` reviewer, until it meets the stability
  criteria in `docs/providers.md`. The default profile is unchanged.
- The `codex` implementer's preflight accepts only Codex CLI versions from
  0.160.0 up to, but not including, 0.161.0, on macOS or Linux; any other
  host stops the run with `IMPLEMENTER_PREFLIGHT_FAILED`.
- The `claude` reviewer's preflight accepts only Claude Code versions from
  2.1.285 up to, but not including, 2.2.0, on macOS or Linux (the
  implementer's range). When a review is required, any other host stops the
  run before the first round with the new code `REVIEWER_PREFLIGHT_FAILED`,
  and the doctor check `reviewer-cli` fails.
- The conformance suite no longer gives the built-in `codex` module a
  warning instead of a failure for a preflight that refuses no host.

### Added

- An optional `reviewer.preflight({ version, platform })` in the provider
  contract, with the implementer's semantics. The core calls it after the
  reviewer's version check, and the conformance suite checks it against
  `reviewer.preflight` fixtures (`accepted`, `refused`) the same way as the
  implementer's.
- `--implementer-model <id>` and `--implementer-effort <effort>`. The
  options `--codex-model` and `--sol-effort` remain as deprecated aliases
  with the same validation; giving an alias together with its new option is
  an argument error. The programmatic options `implementerModel` and
  `implementerEffort` take precedence over the deprecated `codexModel` and
  `solEffort`.

## 0.1.0 — 2026-10-23

The first release. It contains every change listed below.

### 2026-10-23

- Release 0.1.0: `package.json` has version `0.1.0` and `"private": false`.
- `.github/workflows/release.yml` checks that npm in the job is 11.5.1 or
  newer and fails otherwise, without installing another npm. It uses no
  npm token: it publishes through npm trusted publishing from the version
  after 0.1.0. Version 0.1.0 is published by hand, without provenance. The
  workflow test checks that neither workflow uses a secret or
  `NODE_AUTH_TOKEN`.
- README: installation from npm (`npm install --global ringi-gate`,
  `npx ringi-gate`, `npm install --save-dev ringi-gate`) from version 0.1.0;
  running from a checkout stays an alternative.

- An agent CLI that exits before reading its whole prompt from stdin no
  longer crashes the runner with an unhandled `EPIPE` (no JSON report on
  stdout). A failing exit is the agent's own failure, as before; an exit
  with 0 without the whole prompt read stops with `PROCESS_ERROR`. Stop
  codes and report fields of other runs are unchanged.
- The tests that expect an empty stderr from a child run with `NO_COLOR`
  remove `FORCE_COLOR` from its environment, so they pass when `node --test`
  writes to a terminal.

### 2026-10-22

- Documentation, examples, templates and code comments describe the tool
  and its rules directly, in the third person or as instructions. Facts,
  stop codes, report fields and prompts are unchanged.
- The package tests accept both manifest states: unreleased
  (`"private": true`, version `0.0.0`) and a release (`"private": false`,
  any other x.y.z version). Name, license, `bin` and `files` are checked in both;
  the tarball name and `ringi --version` follow the version in
  `package.json`.
- The profile written by `ringi init` starts with the comment
  `Ringi Gate project profile`.
- `.github/workflows/release.yml` lists its requirements: a GitHub
  environment named `release` and npm 11.5.1 or newer for trusted
  publishing.

### 2026-10-21

- Package and workflows (prompts unchanged; the runner fingerprint below
  adds a stop code, a report field and a `ringi doctor` check):
  - `package.json` has a `files` field (`bin/`, `scripts/` without tests
    and `scripts/fixtures/`, `examples/` without its test, `docs/`,
    `LICENSE`, `NOTICE`, `README.md`, `CHANGELOG.md`, `SECURITY.md`) and
    `repository`, `homepage` and `bugs` pointing to
    `github.com/kxmskx/ringi-gate`. It stays `"private": true` at version
    `0.0.0`; nothing is published.
  - New tests (`scripts/ringi-package.test.mjs`, run by `npm test`): the
    file list of `npm pack` and the imports of the packaged modules; an
    offline installation of the packed tarball with npm and with pnpm in a
    synthetic repository, then `ringi --version`, `init`, `doctor --json`
    and `run --dry-run` from `node_modules`, and a run whose stand-in
    writer changes the runner in `node_modules` (`RUNNER_MODIFIED`); a
    text check of the workflows.
  - `.github/workflows/test.yml`: `npm ci` and `npm test` on
    `ubuntu-latest` and `macos-latest` with Node.js 24, read-only token,
    actions pinned to a commit SHA; pnpm 11.20.0 is put into the Corepack
    cache first. `.github/workflows/release.yml`: on a `v*` tag or by hand,
    in the `release` environment, `npm publish --provenance` with npm
    trusted publishing. Neither workflow has run yet.
  - Runner fingerprint: when the runner module loads, it records the
    SHA-256 of every module of the import graph of `bin/ringi.mjs` and
    `scripts/agent-review-loop.mjs` in its installation (regular files
    only, no symbolic links; otherwise no fingerprint and the run stops).
    The run checks them at the profile's check points (after each writer
    round, after the gates, before the reviewer's snapshot, before the
    final report and on every stop) and stops with the new code
    `RUNNER_MODIFIED`, the primary code before `PROFILE_MODIFIED`. Reports
    have a new field `runner` (`sha256`, `files`); the golden snapshots of
    runs omit it (normalization `runnerFingerprint`), their report and
    event hashes are unchanged. A change made before the run is not
    detected.
  - `ringi doctor`: new check `runner-location`, `warn` when the runner lies
    inside the repository (for example `node_modules/ringi-gate`), with the
    hint to install it outside (globally or through `npx`); `ok` outside.

- Name and license: the project is Ringi Gate, licensed under the Apache
  License 2.0 (`LICENSE`, `NOTICE`). `package.json` has `"name":
  "ringi-gate"` and `"license": "Apache-2.0"`; the command stays `ringi`
  and `ringi --version` prints `ringi (Ringi Gate) <version>`. The package
  is not published. Stop codes, report fields, prompts and golden snapshots
  are unchanged.

- Security (Claude Code as implementer and modules from a profile; the
  `codex` path and the default profile's results are unchanged, golden
  snapshots untouched):
  - Process watch (best effort): while the writer CLI runs, the default
    process runner reads the process table with `/bin/ps` or `/usr/bin/ps`
    every 200 ms and identifies a process by its PID and start time; when
    the CLI exits it kills the processes and process groups it saw (also
    those of Bash commands in their own session, as in the probe of
    2.1.285, and a recorded process that moved to another group), never a
    reused PID or a group with a foreign leader, and checks that none
    survived. A survivor, a recorded PID present with another start time
    (a reused PID or a clock step) or an unreadable process table stops the
    run with
    the new code `IMPLEMENTER_PROCESS_SURVIVED`. A process that escaped
    between two readings is not found (see `SECURITY.md`).
  - The Git directory fingerprint, the private index (against a new one
    built from `HEAD`) and the project profile are compared again after
    the gates and after the review (`UNEXPECTED_GIT_MUTATION`,
    `PROFILE_MODIFIED`); the profile check after the review applies to
    every writer. When a gate or the reviewer fails, the Git comparison is
    added to the stop report as an integrity violation.
  - Preflight refuses symbolic links among the `.git` entries the
    fingerprint reads as plain files and directories (`objects/`, `info/`,
    `hooks/` and below, `config`, `HEAD`, `refs` and others). Without a
    private index a core Git command stops (`INTEGRITY_CHECK_FAILED`)
    instead of using the repository index.
  - Provider grid: `codex` `-c` overrides of `notify`, `profile(s)` and the
    `sandbox_workspace_write` table (except `network_access=false`),
    `--profile`/`-p`; `claude --settings` checked on parsed JSON (escaped
    keys), a `sandbox` without `enabled: true` or with
    `allowUnsandboxedCommands` other than `false`, Unix sockets, local
    binding, proxy ports, `enabledPlugins`, `extraKnownMarketplaces`; a
    `claude` reviewer argv without `--tools`, and a lone `-` inside its
    tools; more reserved program names (`arch`, `sandbox-exec`, `tmux`,
    `screen`, `find`, `expect`, `strace`, `java`, `jshell`, editors,
    `crontab`, `at`, `batch`, `Rscript`, `swift`, shells with a hyphenated
    version). The conformance suite requires a
    known `reason` for every refused preflight host. The built-in `codex`
    session ID must meet `isValidSessionId`, like modules from a profile.
- Polish before publication: the `en` writer prompt says that historical
  identifiers are compatibility identifiers to use exactly as given; snapshot
  `baseline` fields hold neutral descriptions instead of commit hashes;
  snapshot diagnostics and test labels in English; adapter snapshots run Git
  without machine configuration; `update-golden.mjs` judges failures by the
  test process exit code. `pl` prompts, stop codes and report fields are
  unchanged.

### 2026-10-20

- Tests in English: test names, assertion messages and comments of the test
  suite are in English and describe behavior, without stage identifiers or
  commit hashes; what the tests check is unchanged (Polish test data stays).
  The `test` field of the golden snapshots follows the new `[golden]` test
  names; snapshot contents are otherwise unchanged. Exceptions: subtests
  named from data tables keep their Polish labels (test data), and the
  `test` field of `cli-profile-history.json`, which does not follow a test
  name, stays Polish. The naming convention is in `docs/testing.md` and
  `CONTRIBUTING.md`.
- English agent prompts and task section names. The profile's `locale` now
  also selects the writer and reviewer prompts and the default task schema.
  With `'en'` (the default) the prompts are in English, name no provider,
  model or project (they speak of the writer, the reviewer and the runner),
  and quote the English section names; every rule of the Polish prompts is
  kept. The default schema has the English canonical names (`goal`, `scope`,
  `acceptance criteria`, `required checks`, `constraints`,
  `deferred items`, optional `task class`, `starting files`,
  `allowed change area`, `review files`) with the Polish names as aliases,
  so existing Polish task files still parse; the parse result keys sections
  by the English names. As before, when the English names were aliases, a
  repeated section heading under the default `'en'` schema is
  `INVALID_TASK`. With `'pl'` prompts and schema are unchanged, byte
  for byte. A profile that declares `taskSchema` keeps it; a schema may now
  name the task class, required checks and review files sections in English
  or Polish. `taskSchemaVersion` stays 1. Stop codes, report and event
  fields, agent result schemas, argv and gates are unchanged. The example
  task, the `ringi init` template and the README use the English headings.
- The compatibility tests compare the runner with golden snapshots in
  `scripts/fixtures/golden/` instead of reading earlier versions of the
  runner from the Git history, so the tests no longer need that history.
  Snapshots are updated only by hand with
  `node scripts/fixtures/update-golden.mjs`; `npm test` never writes them.
  Runner behavior is unchanged.
- Golden snapshots no longer depend on the machine's Git configuration or
  inherited `GIT_*` variables, snapshot files and tests have descriptive
  names, and `update-golden.mjs` exits with a non-zero code when a failure
  left no snapshot candidate. Snapshot contents are unchanged.
- The docs list Git 2.45 or newer as a requirement (the committed-profile
  check sets `GIT_NO_LAZY_FETCH`). The task quality policy that the default
  profile's classes point to is now in English.

### 2026-10-19

- Runner messages in English, with Polish as a localization. Errors and
  diagnostics, stage labels, the dry-run plan, the texts of the built-in
  task classes, the terminal dashboard and summary, and the CLI parser and
  usage come from a message catalog (`scripts/messages/en.mjs`,
  `scripts/messages/pl.mjs`). The new profile field `locale` (`'en'` by
  default, or `'pl'`; any other value is `INVALID_CONFIGURATION`) selects
  the language; nothing else does. With `'pl'` the output is identical to
  the previous runner, also for profile and task validation outside of a
  run. Truncation and omission markers in agent output are recognized in
  both languages, whatever the locale. Stop codes, report and event fields, `stage` values,
  `schemaVersion`, prompts and the default task schema are unchanged.
  `scripts/agent-review-profile.mjs` and the profile written by
  `ringi init` set `locale: 'en'`; the built-in profile's task class texts
  are now English.
- A `ringi` command for any Git repository, run with Node.js from a
  checkout of this repository (there is no npm package yet):
  - `ringi init` writes `ringi.config.mjs`, with gates taken from the
    `check`, `lint` and `test` scripts of `package.json` plus
    `git diff --check`, and a task template with English section names. It
    never overwrites a file and never creates `AGENTS.md` or `CLAUDE.md`;
    `--dry-run` only lists what it would create. It commits nothing and
    says to commit `ringi.config.mjs` before `ringi run`.
  - `ringi doctor` checks Node.js, Git, the branch, staged changes, the
    pinned pnpm and its Corepack cache, `AGENTS.md`, `CLAUDE.md`, the
    profile, its providers and the agent CLIs, with the runner's own
    preflight functions. It is read-only and calls no model; `--json` gives
    a machine-readable result.
  - `ringi run` runs a task with the profile from `ringi.config.mjs` at the
    repository root, with the same options, report and exit codes as before.
- The profile in `ringi.config.mjs` is protected like code the runner runs:
  it is loaded once, before the first round, imports only relative paths and
  Node.js built-ins (no `require`, no symbolic links or other letter case,
  nothing outside the repository but the runner's own modules; no other
  file of the repository is loaded as a module; a refused or missing import
  fails the load even when the profile catches it, also a module Node.js
  cannot load; a FIFO, device or socket in place of a profile file is
  refused without blocking), and the SHA-256 of the file and of every module
  it imports is checked again right after every writer round, after the
  gates, before the review and at every stop of the run except a cleanup
  failure after approval. A change stops the run with the new code
  `PROFILE_MODIFIED`, which is always the primary code (the failure it
  displaced, also a request for a human decision, is listed in
  `integrityViolations`). The report shows the profile's path, fingerprint
  and whether its files were committed at the start. `ringi` refuses to run
  while `GIT_DIR` or `GIT_WORK_TREE` is set.
- Only a committed profile runs. `ringi run` checks `ringi.config.mjs`
  before it imports it, and the modules it imports right after the load,
  before any agent process and the dry-run plan; an untracked file, a
  change in the working tree or the index, or a failed check stops the run
  with the new code `PROFILE_UNCOMMITTED` (exit code `1`). The code of the
  imported modules has run by then; `ringi.config.mjs` itself is not
  imported. Changed behaviour of
  `ringi doctor`: `profile-committed` now comes before `profile` and fails
  (it was a warning after the import), and the profile is not imported then;
  an uncommitted imported module fails `profile`.
- The committed-profile check no longer uses `git status`, which trusts
  index flags, `core.fsmonitor` and `.gitattributes` conversions: the
  runner hashes the bytes on disk as a Git blob and compares the id with
  `HEAD:<path>` and the index entry. A change hidden by `skip-worktree`,
  `assume-unchanged`, a conversion such as `ident` or a fsmonitor, or a
  mode other than a regular file, now stops with `PROFILE_UNCOMMITTED`; the
  check starts no hook, filter or fsmonitor. The message of
  `PROFILE_UNCOMMITTED` names the flags. `HEAD` comes from the repository's
  object database: after a `PROFILE_MODIFIED` or `UNEXPECTED_GIT_MUTATION`
  stop, check `git log`.
- `node scripts/agent-review-loop.mjs` with `scripts/agent-review-profile.mjs`
  behaves exactly as before.

### 2026-10-18

- Open provider interface. Support for another agent CLI is a provider
  module: code that declares its roles, how it builds commands, reads results
  and resumes sessions, and how it meets each safety guarantee. A profile can
  register extra modules through `providerModules`. Role rules live in the
  core: a module that does not declare every implementer guarantee (sandbox,
  no network, no prompts, explicit resume and the rest) cannot be the
  `implementer`, and the `reviewer` needs read-only tools. The declaration is
  the module's own description, so review against the real CLI is still the
  guarantee; the core's integrity checks apply whatever it says. Violations
  stop the run with `PROVIDER_ROLE_NOT_ALLOWED` or
  `PROVIDER_CONTRACT_VIOLATION`.
- The built-in `codex` and `claude` providers moved to `scripts/providers/`
  with unchanged behaviour. A shared conformance suite checks any module
  without calling a model; see [docs/providers.md](docs/providers.md) and the
  template in `examples/providers/`.
- Claude Code can now act as the `implementer`, not only the `reviewer`.
  This is **experimental and not meant for untrusted tasks**. The adapter runs
  Claude Code without permission prompts and never with
  `--dangerously-skip-permissions`. Commands run in a sandbox with no network,
  and writes stay inside the repository. Results come back through
  `--json-schema`, and sessions are resumed explicitly. Supported CLI versions:
  `>=2.1.285 <2.2.0`.
- New fail-closed checks around the implementer:
  - a fingerprint of `.git` stops the run with `UNEXPECTED_GIT_MUTATION`;
  - preflight rejects repositories that use worktrees, submodules or
    alternates;
  - the reviewer's diff is built from a private index created from `HEAD`;
  - staged changes are checked against the repository's real index;
  - permission denials are recorded in the report.
- Known limitation: a background process started through Bash can outlive the
  CLI. See [SECURITY.md](SECURITY.md).
- The default profile (Codex implements, Claude reviews) behaves exactly as
  before.

### 2026-10-17

- Clearer good first issues and a roadmap entry for an open provider
  interface.

### 2026-10-16

- Roles are separate from providers. The profile picks the provider, model,
  effort and review profiles for `implementer` and `reviewer`, and invalid
  combinations fail before the run starts. Reports gained neutral
  `implementer` and `reviewer` fields; the older fields stay as aliases.
- A friendlier repository: README with a terminal demo recorded from a real
  dry run, a contributor guide, good first issues, a code of conduct, and
  issue and pull request templates.

### 2026-10-15

- Task classes and the docs-only candidate policy live in the profile. Core
  rules still apply: only a docs candidate may skip review, and paths with
  agent instructions are always excluded.
- The task schema lives in the profile (Polish section names with English
  aliases by default), and the report records `taskSchemaVersion`. Agent
  prompts moved out of the core into `scripts/agent-review-prompts.mjs`.
- Gate commands are restricted by shape. `pnpm` runs only
  `pnpm [--filter <pkg>] run <script>`, so it cannot start binaries or
  built-in commands. `git` runs only `diff --check`. STOP codes from profile
  rules end in `_GATE`.
- English README and docs, example profile and tasks in `examples/` checked by
  the core parser, and the Ringi mark.

### 2026-10-14

- Gates are profile configuration: checks, check sets, allowed nested calls
  and path-based required gate rules, all validated fail-closed. The default
  profile runs `pnpm check`, `pnpm test` and `git diff --check`.
- The core runs on its own: default profile, `package.json` (Node 24 or
  newer, no runtime dependencies) and tests on synthetic data.
- Initial import of the runner core.
