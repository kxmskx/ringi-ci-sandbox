// English messages of the runner (locale: 'en', the default). Same keys and
// {params} as pl.mjs.
export default Object.freeze({
  'profile.invalid': 'Invalid runner profile.',
  'provider.roleRules': 'The provider does not meet the role rules: {detail}',
  'provider.invalidModule': 'Invalid provider module in the runner profile: {detail}',
  'provider.contractViolation': 'Provider {id} ({role}) violated the core contract: {reason}.',
  'provider.taskMode': 'Provider {id} does not support mode {taskMode} in the {role} role.',
  'provider.argvNotStrings': 'argv is not a list of strings',
  'provider.forbiddenArgument': 'argument {index} disables approvals, the sandbox or the network block',
  'provider.environmentChanged': 'the process environment differs from the core environment',

  'log.omitted': '…[log omitted: diagnostic limit exceeded]…',
  'log.truncated': '…[log truncated]…',
  'log.noOutput': '[no process output]',
  'log.saveFailed': 'Cannot save the bounded diagnostic log: {detail}',
  'log.implementerRound': 'IMPLEMENTER round {round}',
  'log.reviewerRound': 'REVIEWER round {round}',
  'log.reviewerLaneRound': 'REVIEWER lane {lane} round {round}',
  'summary.truncated': '…[summary truncated]…',

  'process.interrupted': 'Stage {stage} interrupted by Ctrl+C.',
  'process.defaultStage': 'process',
  'process.concurrent': 'A concurrent process start was blocked.',
  'process.invalidArgs': 'Process arguments must be an array of strings.',
  'process.exitCode': 'exit code {code}',
  'process.inputNotRead': 'the program exited with 0 without reading its whole input ({error}).',
  'process.stdoutLimit': '{label}: exact stdout exceeded the limit of {limit} bytes.',
  'process.timeout': '{label}: timed out.',
  'program.notFound': 'Program {name} not found in PATH.',

  'config.unknownReviewProfile': 'Unknown review profile {profile}.',
  'config.invalidImplementerModel':
    'The implementer model must be a single identifier (1 to 128 ASCII characters: letters, digits, dot, underscore, hyphen; starting with a letter or digit).',
  'config.unknownSolEffort': 'Unknown writer effort {effort}.',
  'config.invalidTaskMode': 'The task mode must be implementation or analysis.',
  'config.maxRounds': 'The round limit must be an integer from 1 to {max}.',
  'config.modelUnsupported': 'Model {model} is not supported by provider {provider}.',

  'run.interrupted': 'Workflow interrupted by Ctrl+C.',
  'run.maxRounds':
    'The limit of {maxRounds} rounds was reached with open findings. A human decides.',
  'run.reviewOnlyFindings':
    'The review-only run ended with {count} open findings. No writer corrects them: a human decides.',
  'run.reviewOnlyTaskMode':
    'A review-only run reviews an implementation candidate; the analysis mode is not available.',
  'run.reviewOnlyNoChanges':
    'A review-only run needs uncommitted changes relative to HEAD other than the task file; the working tree has none.',
  'run.reviewOnlyClass':
    'Task class {taskClass} skips the independent review; a review-only run needs a class with review.',
  'run.resume':
    "Fix the cause, check the working tree and run the task again. The workflow does not revert the writer's changes.",
  'checkpoint.options':
    'Checkpoints and resume need a run with a writer: not with a dry run or a review-only run.',
  'checkpoint.taskMode': 'Checkpoints and resume are available in the implementation mode only.',
  'checkpoint.runId': 'The run id to resume is not a run id of this runner.',
  'checkpoint.noStateDirectory':
    'The checkpoint key needs XDG_STATE_HOME or HOME as an absolute path.',
  'checkpoint.stateDirectoryUnsafe':
    'The directory of the checkpoint key must be a directory of the current user without access for others (mode 0700), not a symbolic link.',
  'checkpoint.keyMissing': 'The checkpoint key does not exist: no checkpoint can be verified.',
  'checkpoint.keyUnsafe':
    'The checkpoint key must be a regular file of the current user with mode 0600 and 32 bytes, not a symbolic link.',
  'checkpoint.keyWriteFailed': 'The checkpoint key could not be created: {detail}',
  'checkpoint.writeFailed': 'The checkpoint could not be written: {detail}',
  'checkpoint.profileUnhashable': 'The profile cannot be fingerprinted for a checkpoint.',
  'checkpoint.missing': 'Run {runId} has no checkpoint to resume from.',
  'checkpoint.structure': 'The checkpoint of run {runId} is unreadable or malformed; it is not trusted.',
  'checkpoint.signature': 'The checkpoint of run {runId} has no valid signature; it is not trusted.',
  'checkpoint.revoked':
    'Run {runId} stopped with a code that cannot be resumed. A human decides; start a new run.',
  'checkpoint.notResumable':
    'Run {runId} stopped with {code}, which cannot be resumed. A human decides; start a new run.',
  'checkpoint.mismatch':
    'The checkpoint of run {runId} does not match the current {field}; the run cannot be resumed.',
  'checkpoint.completed': 'Run {runId} has no open phase; there is nothing to resume.',
  'checkpoint.roundLimit':
    'Run {runId} used all {maxRounds} rounds; resume does not reset the round limit.',
  'checkpoint.resumeHint':
    'Fix the cause and continue with ringi run <task> --resume {runId}. The working tree must stay as the checkpoint recorded it.',
  'checkpoint.stopRecordFailed':
    'The stop could not be recorded in the checkpoint or revoked ({detail}); the checkpoints of this run were removed and it cannot be resumed.',
  'checkpoint.neutralizeFailed':
    'The stop could not be recorded in the checkpoint or revoked ({detail}), and the checkpoint of run {runIds} could not be removed: do not resume it.',
  'checkpoint.ledger':
    'The ledger of run {runId} does not verify with the checkpoint key ({detail}); the checkpoint is not trusted.',
  'ledger.writeFailed': 'The run ledger could not be written: {detail}',
  'ledger.incomplete':
    'The run ledger is incomplete: an event could not be written. ringi verify reports the mismatch.',
  'cleanup.failed': 'Cleanup failed: {detail}',
  'cleanup.unknownResource': 'Refused to clean up an unknown resource.',

  'git.repositoryUnknown': 'Cannot determine the Git repository',
  'git.wrongRepository': 'The command runs in another repository: {path}.',
  'git.branchUnreadable': 'Cannot read the current branch',
  'git.detachedHead': 'Detached HEAD is not allowed.',
  'git.headUnreadable': 'Cannot read HEAD',
  'git.stagedUnreadable': 'Cannot check staged changes',
  'git.stagedChanges': 'Staged changes found. Workflow stopped.',
  'git.identityChanged': 'Git changed the branch or HEAD during stage {stage}.',
  'git.protectedBranch': 'The workflow requires a working branch; {branch} is not allowed.',
  'runner.modified': 'The runner files changed during the run: {files}. They were fingerprinted when the runner started; the run stops.',
  'runner.unverifiable': 'The runner files cannot be fingerprinted ({detail}); the run stops.',
  'runner.modifiedResume': 'Check the runner installation (reinstall it, preferably outside the repository) and the working tree, then run the task again.',
  'git.directoryTooLarge': 'The Git directory exceeds the integrity fingerprint limit.',
  'git.objectsTooLarge': 'The Git object database exceeds the integrity fingerprint limit.',
  'git.refsUnreadable': 'Cannot read Git refs',
  'git.indexFlagsUnreadable': 'Cannot read Git index flags',
  'git.indexEntriesUnreadable': 'Cannot read Git index entries',
  'git.directoryUnreadable': 'Cannot read the Git directory',
  'git.privateIndexBuild': 'Cannot build the private Git index',
  'git.privateIndexRefresh': 'Cannot refresh the private Git index',
  'git.privateIndexMissing':
    'The private Git index is missing; the core does not fall back to the repository index. Workflow stopped.',

  'implementer.gitStateChanged':
    'The writer changed Git state outside the working tree ({changed}). Workflow stopped before the gates.',
  'implementer.gitStateChangedLater':
    "Git state outside the working tree changed after the writer's round ({changed}), found at stage {stage}. Workflow stopped.",
  'implementer.processSurvived':
    'Processes started by the writer CLI survived its exit and could not be killed (PID {pids}). Workflow stopped.',
  'implementer.processCheckUnavailable':
    'Cannot check whether processes started by the writer CLI survived its exit (the process table is unreadable). Workflow stopped.',
  'implementer.processIdentityChanged':
    'Cannot check whether processes started by the writer CLI survived its exit: a recorded PID is present with another start time (PID {pids}). Workflow stopped.',
  'implementer.layoutSymlink': 'the Git directory has a symbolic link at {path}',
  'implementer.scratchNotEmpty':
    'The writer CLI scratch directory {path} is not an empty directory. Workflow stopped.',
  'implementer.layout': 'Writer {program} requires a plain Git repository: {reason}.',
  'implementer.layoutDotGit': '.git is not a directory (linked worktree or submodule)',
  'implementer.layoutGitmodules': 'the repository has a .gitmodules file (submodules)',
  'implementer.layoutGitDirectory': 'the Git directory is not the .git directory of the repository',
  'implementer.layoutEntries': 'the Git directory has entries in {name}/',
  'implementer.layoutAlternates': 'the object database has an alternates file',

  'task.duplicateSection': 'Section "{title}" appears more than once in the task file.',
  'task.checksBackticks': 'The "Required checks" section must list commands in backticks.',
  'task.unsupportedCheck':
    'Unsupported check {command}. The workflow does not run text as a shell command.',
  'task.reviewFilesRequired': 'Analysis mode requires a non-empty "Review files" section.',
  'task.reviewFilesBackticks':
    'The "Review files" section accepts only a list of exact paths in backticks.',
  'task.reviewFilesNonCanonical':
    'The "Review files" section contains a non-canonical path, a glob or an escape.',
  'task.reviewFilesCount': 'The "Review files" section must contain 1 to {max} paths.',
  'task.reviewFilesDuplicate': 'The "Review files" section contains a duplicate path.',
  'task.reviewFilesSame': 'The "Review files" section names the same file more than once.',
  'task.reviewFilesTotal': 'The total size of the review files exceeds the 32 MiB limit.',
  'task.reviewFileMissing': 'Review file {path} does not exist.',
  'task.reviewFileLink': 'Review file {path} must not pass through a symbolic link.',
  'task.reviewFileUnsafe': 'Review file {path} is not a safe regular file.',
  'task.reviewFileSize': 'Review file {path} must be a regular file of up to 8 MiB.',
  'task.reviewFileNonCanonical': 'Review file {path} is not a canonical repository-relative path.',
  'task.tooLarge': 'The task file exceeds the 256 KiB limit.',
  'task.classHeading': 'The "Task class" section must have a level ## heading.',
  'task.classInvalid': 'Invalid or incompatible "Task class" section.',
  'task.sectionMissing': 'The task file has no non-empty "{section}" section.',
  'task.pathMissing': 'Provide the path to a Markdown task file.',
  'task.notInRepository': 'The task file must be inside the repository.',
  'task.notRegular': 'The task file must be a regular file, not a symbolic link.',
  'task.escapes': 'The task file is outside the repository.',
  'task.analysisPathLength': 'The analysis task path exceeds the 500 character limit.',

  'taskClass.reviewRequiredReason':
    'The class requires independent review; analysis keeps its own contract.',
  'taskClass.reviewRequiredAssurance':
    'A separate checkpoint of the whole scope and a human decision before publication.',
  'taskClass.docsReason':
    'Approved docs-minor/docs-descriptive policy: writer self-check and documentation gates.',
  'taskClass.docsAssurance':
    'No independent semantic review; coordinator classification, source verification by the writer and a checkpoint before publication.',

  'secret.providerToken': 'provider token',
  'secret.authorizationHeader': 'authorization header',
  'secret.urlCredentials': 'credentials in URL',
  'secret.secretVariable': 'suspicious secret variable',
  'secret.suspiciousPath': 'suspicious file path',
  'secret.defaultPath': 'content',
  'secret.detected': 'Suspicious credentials found in {path}: {labels}.',
  'secret.newFindings': 'New suspicious credentials found ({count}): {summary}. Values hidden.',
  'secret.filesUnreadable': 'Cannot read the files for the secret scan',
  'secret.trackedUnreadable': 'Cannot read the tracked files for the baseline secret scan',
  'secret.basePathsUnreadable': 'Cannot read the baseline paths for the secret scan',
  'secret.baseVersionUnreadable': 'Cannot read the baseline version of {path}',

  'docker.invalidHost':
    'Invalid DOCKER_HOST. Only the standard local Docker socket unix:// is allowed.',

  'deps.metadataMissing':
    'Local dependency metadata is missing. Run manually outside the workflow: pnpm install --frozen-lockfile.',
  'deps.metadataSymlink': 'Protected dependency metadata path {path} contains a symbolic link.',
  'deps.metadataNotRegular':
    'Protected dependency metadata path {path} is not a regular file in regular directories.',
  'deps.metadataFileLimit': 'Protected dependency metadata file {path} exceeds the {limit} B limit.',
  'deps.metadataFileChanged': 'Protected dependency metadata file {path} changed while being read.',
  'deps.metadataTotalLimit': 'Protected dependency metadata exceeds the total limit of {limit} B.',
  'deps.metadataChanged':
    'Local dependency metadata changed during the workflow. It is not restored automatically; check node_modules and run a deliberate install outside the loop.',
  'deps.inputSymlink': 'Dependency input {path} must not be a symbolic link.',
  'deps.inputTotalLimit': 'Dependency inputs exceed the total limit of {limit} B.',
  'deps.inputsChanged':
    'Dependency inputs changed during the workflow. Check the diff, run pnpm install --frozen-lockfile deliberately outside the loop, approve the scope again and run the workflow from the start. The changes were not reverted.',
  'deps.repair':
    '{reason} Run manually outside the workflow: pnpm install --frozen-lockfile. The workflow does not repair or copy the lockfile.',
  'deps.validationEscape': 'A dependency validation input is outside the temporary directory.',
  'deps.lockMismatch':
    'pnpm-lock.yaml and the installed node_modules/.pnpm/lock.yaml are not byte-identical.',
  'deps.manifestsUnverifiable': 'Cannot verify that the manifests match pnpm-lock.yaml',
  'deps.manifestsMismatch': 'The package.json manifests do not match pnpm-lock.yaml ({detail}).',

  'pnpm.pinExact': 'The packageManager field must pin an exact pnpm version.',
  'pnpm.pinFormat': 'The packageManager field must have the form pnpm@<exact-version>.',
  'pnpm.onlyPnpm': 'The workflow supports only the pnpm packageManager.',
  'pnpm.pinSemver': 'The packageManager field must pin an exact semver pnpm version.',
  'pnpm.integritySuffix':
    'The packageManager integrity suffix must have a form Corepack supports: sha<algorithm>.<full-hex-hash>.',
  'pnpm.packageJsonRegular': 'package.json must be a regular file with a pinned pnpm version.',
  'pnpm.packageJsonInvalid': 'package.json is not valid JSON.',

  'corepack.homeAbsolute': 'The local Corepack cache path must be absolute.',
  'corepack.versionMissing':
    'The exact pnpm version is missing from the local Corepack cache or is a symbolic link. Prepare it manually: corepack install -g --cache-only pnpm@<version>.',
  'corepack.cacheEntries': 'The pnpm cache exceeds the limit of {limit} entries.',
  'corepack.cacheLink': 'The pnpm cache contains a forbidden symbolic link: {path}.',
  'corepack.cacheEscape': 'A pnpm cache entry is outside the exact version directory.',
  'corepack.cacheUnsupported': 'The pnpm cache contains an unsupported entry: {path}.',
  'corepack.cacheBytes': 'The pnpm cache exceeds the limit of {limit} bytes.',
  'corepack.cacheChangedRead': 'The pnpm cache changed during the safe read.',
  'corepack.homeMissing': 'The local COREPACK_HOME does not exist.',
  'corepack.homeNotDirectory': 'The source COREPACK_HOME must be a real directory.',
  'corepack.pinnedLink': 'The path to the pinned pnpm version contains a forbidden symbolic link.',
  'corepack.pinnedEscape': 'The pinned pnpm version is outside the source COREPACK_HOME.',
  'corepack.isolatedExists': 'The isolated pnpm cache already exists.',
  'corepack.sourceChanged': 'The source pnpm cache changed during the copy.',
  'corepack.integrityMissing': 'The cache of the pinned pnpm version has no safe integrity metadata.',
  'corepack.integrityInvalid': 'The pnpm cache integrity metadata is invalid.',
  'corepack.integrityMismatch': 'The integrity of the local pnpm cache does not match packageManager.',
  'corepack.checkCacheChanged': 'The isolated pnpm cache of the checks changed after preflight.',
  'corepack.runPinned': 'Cannot run the pinned pnpm version in the {label} environment',
  'corepack.versionMismatch': 'Isolated Corepack ({label}) ran pnpm {actual}, expected {expected}.',
  'corepack.labelWriter': 'writer',
  'corepack.labelChecks': 'checks',
  'corepack.cacheMissing':
    'No local cache for {specification}. Prepare it manually before the workflow: corepack install -g --cache-only {specification}.',
  'corepack.copiesUnconfirmed': 'Cannot confirm independent, identical copies of the pnpm cache.',

  'output.wrongFields': '{label} has wrong fields.',
  'output.invalidJson': '{label} returned invalid JSON.',
  'label.findingResponse': 'Response {status}',
  'label.writerResult': 'Writer result',
  'label.reviewerResult': 'Reviewer result',
  'label.reviewerOutput': 'Reviewer output',
  'label.reviewerFinding': 'Reviewer finding',
  'label.confirmation': 'Confirmation of {label}',
  'label.analysisConfirmation': 'Analysis review confirmation',
  'label.readTask': 'the original task',
  'label.readManifest': 'the manifest',
  'label.readArtifact': 'the artifact',
  'label.readReviewFile': 'the review file {path}',

  'writer.invalidResponse': 'The writer returned an invalid finding response.',
  'writer.confirmedFields':
    'A CONFIRMED response requires analysis, evidence, a fix, a regression test or a justification, the checks that were run, and an empty question.',
  'writer.rejectedFields':
    'A REJECTED response requires analysis and a reproduction attempt, evidence or a specific justification; fix, regressionTest and question must be empty.',
  'writer.needsHumanFields':
    'A NEEDS_HUMAN response requires a specific question or a description of the conflict, and all other fields empty.',
  'writer.invalidResponses': 'The writer returned an invalid list of finding responses.',
  'writer.analysisMissing': 'The writer did not return the required full analysis.',
  'writer.invalidResult': 'The writer returned an invalid structured result.',
  'writer.analysisFieldMissing': 'The writer did not return the required full analysis field.',
  'writer.analysisMetadata':
    'Analysis mode requires empty changes and short metadata without the artifact sentinel.',
  'writer.unknownFindingId': 'The writer responded to an unknown findingId {findingId}.',
  'writer.duplicateResponse': 'The writer returned more than one response for {findingId}.',
  'writer.incompleteResponses':
    'The writer did not return a complete set of finding responses: {missing}.',
  'writer.responseCountMismatch': 'response count mismatch',
  'writer.needsHumanConflict': 'A NEEDS_HUMAN response contradicts the status of the writer result.',
  'writer.stopped': 'The writer stopped with status {status}: {summary}',
  'writer.offlineConfig': 'The writer environment has no complete offline pnpm configuration.',
  'writer.sessionId': 'Cannot determine the writer session ID.',
  'writer.roundFailed': 'The writer did not complete the round',
  'writer.noResult': 'The writer did not save a structured result.',
  'writer.analysisWrite': 'The writer tried to write to the working tree in analysis mode.',

  'analysis.tooLarge': 'The full analysis exceeds the 512 KiB limit.',
  'analysis.sentinel':
    'The full analysis does not end with exactly one completeness sentinel.',
  'analysis.truncated': 'The full analysis contains a truncation marker.',
  'analysis.heading':
    'The full analysis requires at least one unique semantic Markdown heading.',

  'reviewer.readUnconfirmed': 'The reviewer did not confirm reading {label}.',
  'reviewer.readMismatch': 'The reviewer returned a mismatching read confirmation for {label}.',
  'reviewer.manifestMissing': 'The runner has no expected manifest of analysis review confirmations.',
  'reviewer.confirmationMissing': 'The reviewer did not return the analysis review confirmation.',
  'reviewer.filesUnconfirmed': 'The reviewer did not confirm the exact set of review files.',
  'reviewer.filesMismatch':
    'The reviewer returned an incomplete, unexpected or duplicated set of review files.',
  'reviewer.invalidResult': 'The reviewer returned an invalid structured result.',
  'reviewer.verdictConflict': 'The analysis review verdict contradicts the findings list.',
  'reviewer.invalidFinding': 'The reviewer returned an invalid finding.',
  'reviewer.findingOutside': 'The reviewer returned a finding with a path outside the repository.',
  'reviewer.analysisFindingTarget':
    'An analysis finding must name the logical artifact and the exact heading of its section.',
  'reviewer.noStructuredOutput': 'The reviewer did not return structured_output.',
  'reviewer.findingAmbiguousPath':
    'The reviewer returned a finding with a path outside the repository or an ambiguous path.',
  'reviewer.findingAmbiguousFields': 'The reviewer returned ambiguous stable finding fields.',
  'reviewer.findingIdMismatch':
    'The reviewer gave a findingId that does not match the stable fields for {file}.',
  'reviewer.invalidModel': 'Reviewer model {model} is invalid.',
  'reviewer.reviewFailed': 'The reviewer did not complete the review',
  'reviewer.fallbackFailed': 'The reviewer fallback did not complete the review.',
  'reviewer.laneFailed': 'Review lane {lane}: {message}',
  'reviewer.laneCoverage':
    'The paths of the review lanes do not cover {count} changed file(s), so no reviewer started: {files}. Add the files to a lane, or add a lane without paths.',

  'finding.identityCollision': 'Stable identity collision: {findingId}.',
  'finding.identityDuplicate': 'The review contains an ambiguously duplicated identity {findingId}.',
  'finding.needsHuman': 'Finding {findingId} needs a human decision: {question}',
  'finding.dispute':
    'The reviewer upheld finding {findingId}, which the writer rejected on technical grounds. A human decides, whatever the severity.',

  'guard.gitBlocked': 'Agent review loop: mutating or unknown Git operation blocked.',
  'guard.pnpmBlocked': 'Agent review loop: mutating or unknown pnpm operation blocked.',
  'guard.corepackBlocked': 'Agent review loop: mutating or unknown Corepack operation blocked.',
  'guard.callBlocked': 'Agent review loop: call to {name} blocked.',
  'guard.notInstalled': 'Agent review loop: the real {name} is not installed.',

  'repo.filesUnreadable': 'Cannot read the repository files',
  'repo.absolutePath': 'Git returned an absolute path.',
  'repo.pathEscape': 'A repository path is outside the root.',
  'repo.linkAbsolute': 'Symbolic link {path} has an absolute target.',
  'repo.linkEscape': 'Symbolic link {path} points outside the repository.',
  'repo.linkParent':
    'Path {path} passes through symbolic link {link}. Only the last part of a path may be a symbolic link.',
  'repo.reviewContextReserved':
    'Path {path} uses .review-context, a name reserved for the review context of the snapshot.',
  'repo.unsupportedEntry': 'Unsupported entry type {path}.',
  'repo.fileTooLarge': 'File {path} exceeds the 8 MiB limit. Split the task.',
  'repo.stateTooLarge': 'The repository state exceeds the 64 MiB copy limit. Split the task.',
  'repo.candidateUnreadable': 'Cannot read the whole candidate',
  'repo.newFilesUnreadable': 'Cannot read the new files',
  'repo.headTypeUnreadable': 'Cannot check the file type in HEAD',
  'gates.ruleRequired': 'A change to paths covered by a profile rule requires an explicit {check} in the task.',
  'docs.candidateForbidden': 'The docs candidate contains a forbidden file or type: {path}.',

  'diff.trackedFailed': 'Cannot create the diff of tracked files',
  'diff.untrackedUnreadable': 'Cannot read untracked files',
  'diff.pathFailed': 'Cannot create the diff of {path}',
  'diff.pathFailedDetail': 'Cannot create the diff of {path}: {detail}',
  'diff.tooLarge': 'The full diff exceeds the 16 MiB limit.',

  'snapshot.unsupportedEntry': 'The snapshot contains an unsupported entry type {path}.',
  'snapshot.treeChangedReview': 'The real working tree changed during the review.',
  'snapshot.changedDuringReview': 'The review snapshot changed during the review.',
  'snapshot.packagePathEscape': 'A review package path is outside the root.',
  'snapshot.artifactChanged': 'The analysis artifact changed while the review package was created.',
  'snapshot.artifactCopyMismatch':
    'The artifact copy in the review package has a mismatching hash or size.',
  'snapshot.reviewFileChanged': 'Review file {path} changed type or content before the snapshot.',
  'snapshot.treeChangedAnalysis': 'The working tree changed while the analysis package was created.',
  'snapshot.analysisPackageTooLarge': 'The minimal analysis review package exceeds the 64 MiB limit.',
  'snapshot.treeChangedCopy': 'The working tree changed while the reviewer copy was created.',

  'artifact.overwrite': 'Refused to overwrite an existing artifact.',
  'artifact.writeFailed': 'Cannot write the analysis artifact atomically: {detail}',
  'artifact.metadataMissing': 'The analysis artifact metadata is missing.',
  'artifact.missing': 'The analysis artifact is gone or is not a safe regular file.',
  'artifact.changed': 'The analysis artifact is gone or changed type, inode, permissions or size.',
  'artifact.hashMismatch': 'The analysis artifact hash does not match.',
  'artifact.contract': 'The analysis artifact content does not meet the recorded completeness contract.',

  'gates.noOutput': 'No output; the process exited with code 0.',
  'gates.reportNotPass': 'Cannot create the trusted report: not all required gates passed.',
  'gates.reportStructure': 'The trusted gate report has an invalid structure.',
  'gates.reportEntry': 'The trusted gate report has an invalid entry.',
  'integrity.reportStructure': 'The internal analysis check report has an invalid structure.',
  'check.timeout': 'Check {name}: timed out.',
  'check.signal': 'Check {name} was interrupted by signal {signal}.',
  'check.failed': 'Check {name} failed: {detail}',
  'check.treeChanged': 'A check changed the working tree. The next check will not run.',
  'check.treeChangedStop': 'The checks changed the working tree. Workflow stopped.',

  'preflight.versionUnreadable': 'Cannot run {command}',
  'preflight.unsupportedVersion':
    '{program} {version} is not supported in the writer (implementer) role.',
  'preflight.unsupportedPlatform':
    'Platform {platform} does not support the {program} command sandbox in the writer role.',
  'preflight.refused': 'The preflight of provider {id} refused the writer role on this host.',
  'preflight.sandboxUnconfirmed': 'The sandbox check of provider {id} before round {round} did not show a working sandbox ({reason}); the writer was not started.',
  'preflight.reviewerUnsupportedVersion':
    '{program} {version} is not supported in the reviewer role.',
  'preflight.reviewerUnsupportedPlatform':
    'Platform {platform} is not supported for {program} in the reviewer role.',
  'preflight.reviewerRefused':
    'The preflight of provider {id} refused the reviewer role on this host.',

  'stage.preflight': 'Repository and tool validation',
  'stage.analysis': 'Read-only analysis',
  'stage.analysisCorrection': 'Analysis correction',
  'stage.implementation': 'Implementation',
  'stage.findingsCorrection': 'Findings correction',
  'stage.analysisChecks': 'Read-only analysis checks',
  'stage.analysisPackage': 'Minimal read-only analysis package',
  'stage.isolatedCopy': 'Isolated read-only copy',
  'stage.reviewAttempt': 'Review {profile} · {model} · effort {effort} · attempt {attempt}',
  'stage.reviewLaneAttempt':
    'Review lane {lane} · {profile} · {model} · effort {effort} · attempt {attempt}',

  'plan.analysisWriter': 'writer: full read-only analysis',
  'plan.analysisIntegrity': 'internal integrity checks',
  'plan.analysisArtifact': 'separate Markdown artifact with SHA-256',
  'plan.analysisPackage': 'minimal read-only review package',
  'plan.analysisReview': 'reviewer: substantive review',
  'plan.analysisCorrection': 'full analysis correction after every BLOCKER/HIGH/MEDIUM/LOW finding',
  'plan.docsWriter': 'writer: documentation and source verification',
  'plan.checks': 'deterministic checks',
  'plan.implementationWriter': 'writer: implementation',
  'plan.isolatedCopy': 'isolated read-only copy',
  'plan.implementationReview': 'reviewer: diff-first review',
  'plan.implementationCorrection': 'writer correction after every BLOCKER/HIGH/MEDIUM/LOW finding',
  'plan.noMutations': 'none',
  'plan.reviewOnlyInput': 'no writer: the uncommitted changes relative to HEAD are the candidate',
  'plan.reviewOnlyFindings': 'no correction round: any finding stops the run for a human decision',

  'report.docsApproval':
    'APPROVE means the required docs checks ran; independent review is NOT_REQUIRED.',
  'report.analysisApproval':
    'APPROVE means a positive analysis review, not a code review or approval to publish.',
  'report.nextStep':
    'A human checks the result. APPROVE is not approval to commit, push, open a PR or merge.',

  'dashboard.yes': 'yes',
  'dashboard.no': 'no',
  'dashboard.noDetails': 'No details.',
  'dashboard.defaultResume': 'Fix the cause and run the task again.',
  'dashboard.feedRoundStart': 'Round {round} · START',
  'dashboard.feedWaiting': 'waiting',
  'dashboard.feedReviewResult': 'REVIEWER · review result',
  'dashboard.round': 'round {round}/{max}',
  'dashboard.beforeReview': 'before review',
  'dashboard.lastKnownResult': 'last known result',
  'dashboard.reviewResult': 'review result',
  'dashboard.waitingForEvent': 'Waiting for an event',
  'dashboard.gatesLine': '{gates} · PASS {passed} · active {active}',
  'dashboard.agentLine': 'Model {model} · effort {effort} · attempt {attempt}/{limit}{fallback}',
  'dashboard.error': 'Error {error}',
  'dashboard.next': 'Next {resume}',
  'dashboard.modeLine': 'Mode {mode} · {round} · branch {branch}',
  'dashboard.classLine': 'Class {taskClass} · review {review}',
  'dashboard.reviewNotRequired': 'Review NOT_REQUIRED · no independent review',
  'dashboard.zeroFindings': 'ZERO_FINDINGS · threshold B/H/M/L=0 · {result}',
  'dashboard.noReview': '— (no review)',
  'dashboard.codeLine': 'Code {code} · {stage}',
  'dashboard.classGates': 'Class {taskClass} · gates {gates}',
  'dashboard.reviewCalls': 'Review NOT_REQUIRED · calls 0',
  'dashboard.reviewAttempts': 'Review {profile} · attempts {attempts}',
  'dashboard.fallbackUsed': 'fallback allowed {allowed} · used {used}',
  'dashboard.reportPath': 'Report {path}',
  'dashboard.reviewPlan': 'Review {profile} · attempts {attempts} · fallback allowed {allowed}',
  'dashboard.recent': 'RECENT TRANSITIONS',
  'dashboard.appendPreflight': 'PREFLIGHT  run {runId} · branch {branch}',
  'dashboard.appendMode': 'MODE  {mode}',
  'dashboard.appendClass': 'CLASS  {taskClass} · gates {gates}',
  'dashboard.appendAssurance': 'REMAINING ASSURANCE  {assurance}',
  'dashboard.appendReview': 'REVIEW  {profile} · attempts {attempts} · fallback allowed {allowed}',
  'dashboard.appendRound': 'ROUND {round}/{max}',
  'dashboard.laneContext': 'prompt {bytes} B · diff files {files}',
  'dashboard.task': 'Task {path} · mode {mode}',
  'dashboard.diagnostics': 'DIAGNOSTICS',
  'dashboard.choices': '{list} or {last}',

  'cli.taskModeOnce': 'The --task-mode option can be given only once.',
  'cli.taskModeValue': 'The --task-mode option requires the value implementation or analysis.',
  'cli.missingValue': 'The {option} option requires a value.',
  'cli.reviewProfileOnce': 'The --review-profile option can be given only once.',
  'cli.reviewProfileValue': 'The --review-profile option requires the value {choices}.',
  'cli.implementerModelOnce': 'The {option} option can be given only once.',
  'cli.implementerModelValue':
    'The {option} option requires a single identifier (1 to 128 ASCII characters: letters, digits, dot, underscore, hyphen; starting with a letter or digit).',
  'cli.implementerEffortValue': 'The {option} option requires the value {choices}.',
  'cli.implementerEffortConflict': 'The {option} option has conflicting values {first} and {second}.',
  'cli.optionAliasConflict':
    'The {option} option and its deprecated alias {alias} cannot be given together.',
  'cli.unknownOption': 'Unknown option: {option}',
  'cli.oneTaskPath': 'Exactly one task path is required.',
  'cli.reviewOnlyTaskMode': 'The --review-only option works only with --task-mode implementation.',
  'cli.reviewOnlyImplementer': 'The {option} option cannot be given with --review-only: no writer runs.',
  'cli.checkpointOptions':
    'The --checkpoint and --resume options need a run with a writer in --task-mode implementation: not with --dry-run or --review-only.',
  'cli.resumeOnce': 'The --resume option can be given only once.',
  'cli.usage':
    'Usage: pnpm agents:run -- path/to/task.md [--task-mode {taskModes}] [--implementer-model <id>] [--implementer-effort {efforts}] [--review-profile {profiles}] [--dry-run] [--verbose] [--no-animation] [--json]',
  'cli.criticalOpus':
    'critical-opus: model {model}; effort {effort}; attempts {attempts}; fallback {fallback}.',
  'cli.fallbackAllowed': 'allowed',
  'cli.fallbackNone': 'none',
});
